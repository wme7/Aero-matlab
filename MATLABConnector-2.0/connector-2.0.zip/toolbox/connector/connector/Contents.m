% MATLAB Connector
% Version 2.0 (R2012a) 01-Jan-2012
%
% MATLAB Connector 
%   connector      - Enables the MATLAB Connector

% Helper Files
%   setupconnector - Set up the MATLAB Connector on the desktop
%   connector-help - Help text for MATLAB Connector

%   Copyright 2010-2012 The MathWorks, Inc. 