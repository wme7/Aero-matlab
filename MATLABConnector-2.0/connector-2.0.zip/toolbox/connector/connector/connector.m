% CONNECTOR Enables the MATLAB Connector.
%
% connector on             Turns on connector
% connector on password    Turns on the connector with the specified password
% connector off            Turns off connector
%
% Example:
%
% connector on password
% % Point your web browser to: http://localhost:31415/

% Copyright 2012 The MathWorks, Inc.
